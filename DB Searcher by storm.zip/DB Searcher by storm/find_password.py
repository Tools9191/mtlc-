import os
from colorama import Fore, Style

# Remplace par ton chemin d'accès
folder_path = r"C:\Users\Storm\Desktop\Database\DB"

def print_header():
    # Affichage du titre en vert
    print(Fore.GREEN + "\n" + "="*50)
    print(Fore.GREEN + "    DB SEARCHER BY STORM".center(50))
    print(Fore.GREEN + "="*50 + Style.RESET_ALL)

def search_in_files(keyword):
    results_found = False  # Variable pour vérifier si des résultats ont été trouvés
    # Vérifie les fichiers texte dans le dossier spécifié
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt"):  # Recherche uniquement les fichiers .txt
            file_path = os.path.join(folder_path, filename)
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                    lines = file.readlines()
                    for i, line in enumerate(lines):
                        if keyword.lower() in line.lower():
                            results_found = True
                            # Affichage de la ligne avec le mot-clé en vert
                            highlighted_line = line.replace(keyword, f"{Fore.GREEN}{keyword}{Style.RESET_ALL}")
                            print(f"\n{'-'*50}\nFichier: {filename} - Ligne {i + 1}:\n{highlighted_line.strip()}")
            except Exception as e:
                print(f"Erreur avec le fichier {filename}: {e}")
    
    if not results_found:
        print("\nAucun résultat trouvé pour le mot-clé.")

def main():
    print_header()  # Affiche l'en-tête avec le titre
    while True:
        keyword = input("\nEntre le mot-clé à rechercher dans tes DB (ou 'exit' pour quitter): ").strip()
        if keyword.lower() == 'exit':
            break
        search_in_files(keyword)

if __name__ == "__main__":
    main()
